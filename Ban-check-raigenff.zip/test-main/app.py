# ==========================================
# Code created by Rohan
# Telegram: @raigenffofc
# ==========================================

from flask import Flask, request, jsonify
import requests

# Code created by Rohan - App Initialization
app = Flask(__name__)

# Telegram: @raigenffofc - Authorized API Keys Setup
AUTHORIZED_TOKENS = {
    "raigenrohan": "active" # আপনার নতুন API Key
}

# Code created by Rohan - Key Verification Route
@app.route("/check_key", methods=["GET"])
def verify_key_route():
    token = request.args.get("key", "")
    is_valid, response_data = check_access(token)
    
    # Telegram: @raigenffofc - Access Validation
    if not is_valid:
        return jsonify(response_data)
    
    return jsonify({
        "status": "valid", 
        "key_status": AUTHORIZED_TOKENS.get(token, "unknown")
    })

# Code created by Rohan - Main Ban Check Route
@app.route("/bancheck", methods=["GET"])
def check_player_ban():
    token = request.args.get("key", "")
    target_uid = request.args.get("uid", "")

    # Telegram: @raigenffofc - Token Check
    is_valid, auth_response = check_access(token)
    if not is_valid:
        return jsonify(auth_response)

    if not target_uid:
        return jsonify({"error": "Player ID is required", "status_code": 400})

    return fetch_garena_data(target_uid)

# Code created by Rohan - Data Fetching Function
def fetch_garena_data(uid):
    api_url = f"https://ff.garena.com/api/antihack/check_banned?lang=en&uid={uid}"
    req_headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "referer": "https://ff.garena.com/en/support/",
        "x-requested-with": "B6FksShzIgjfrYImLpTsadjS86sddhFH"
    }

    try:
        # Telegram: @raigenffofc - Request Execution
        res = requests.get(api_url, headers=req_headers)
        if res.status_code == 200:
            parsed_data = res.json().get("data", {})
            banned_status = parsed_data.get("is_banned", 0)
            ban_duration = parsed_data.get("period", 0)

            # Code created by Rohan - JSON Output Formatting
            output = {
                "creator": "Code created by Rohan",
                "telegram": "@raigenffofc",
                "channel_link": "https://t.me/raigenffofc",
                "uid": uid,
                "is_banned": bool(banned_status),
                "status": "BANNED" if banned_status else "NOT BANNED",
                "ban_period": ban_duration if banned_status else 0
            }
            return jsonify(output)
        else:
            return jsonify({"error": "Failed to fetch data from server", "status_code": 500})
            
    except Exception as e:
        return jsonify({"error": str(e), "status_code": 500})

# Code created by Rohan - Authentication Helper
def check_access(token):
    if not token:
        return False, {"error": "API key is missing", "status_code": 401}
    
    # Telegram: @raigenffofc - Key Status Check
    if token not in AUTHORIZED_TOKENS:
        return False, {"error": "Invalid API key", "status_code": 401}
    
    token_state = AUTHORIZED_TOKENS[token]
    if token_state == "inactive":
        return False, {"error": "API key is changed", "status_code": 403}
        
    if token_state == "banned":
        return False, {"error": "API key is banned", "status_code": 403}
    
    return True, {"valid": True}

# ==========================================
# Code created by Rohan
# Telegram: @raigenffofc
# ==========================================
if __name__ == "__main__":
    app.run(debug=True)
